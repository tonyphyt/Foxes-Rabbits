
public class FnRMain {

	public static void main(String[] args) {
		Simulator s = new Simulator(100, 100);
		s.simulate(500);
	}

}
